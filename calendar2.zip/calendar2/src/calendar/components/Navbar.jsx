import { useAuthStore } from "../../hooks"



export const Navbar = () => {
  const { startLogout, user } = useAuthStore();
  const { status } = useAuthStore();
  



  return (
    <div className="navbar navbar-dark mb-4 px-4" style={{ backgroundColor: '#003366' }}>
      
        <span className="navbar-brand">
          
        {
                ( status === 'not-authenticated')  
                    ? <>Seweryn</>
                    : (
                        <>
                            { user.name }
                        </>
                    )
            }
        </span>

        <button className="btn btn-outline-danger"
        onClick={ startLogout }>

            <i className="fas fa-sign-out-alt"></i>
            <span>Salir</span>
        </button>
    </div>
  )
}

