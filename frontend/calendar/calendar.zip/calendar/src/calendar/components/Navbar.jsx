
// { user.name } donde Seweryn
export const Navbar = () => {
  return (
    <div className="navbar navbar-dark mb-4 px-4" style={{ backgroundColor: '#003366' }}>
      
        <span className="navbar-brand">
          
            Seweryn
           
        </span>

        <button className="btn btn-outline-danger">
            <i className="fas fa-sign-out-alt"></i>
            <span>Salir</span>
        </button>
    </div>
  )
}
